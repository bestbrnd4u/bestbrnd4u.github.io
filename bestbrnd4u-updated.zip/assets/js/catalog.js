let products = [];

const grid = document.getElementById("catalogGrid");
const search = document.getElementById("searchInput");

// плавний скрол до першого товару в каталозі — викликається
// після застосування фільтрів (мобільна шторка "Всі фільтри"
// та десктопні випадаючі списки), щоб користувач одразу бачив
// оновлений результат
function scrollToFirstProduct() {

    if (!grid) return;

    // ціль — рядок ".catalog-top" ("Знайдено N товарів" + сортування),
    // а не сама перша картка: так після застосування фільтра одразу
    // видно і кількість знайдених товарів, і початок першої картки
    // під ним
    const catalogTop = document.querySelector(".catalog-top");
    const firstCard = grid.querySelector(".product-card");
    const target = catalogTop || firstCard || grid;

    const headerEl = document.querySelector("header");
    const mobileBar = document.querySelector(".mobile-filter-bar");
    const desktopBar = document.querySelector(".catalog-filters-bar");

    let offset = headerEl ? headerEl.offsetHeight : 0;

    if (mobileBar && getComputedStyle(mobileBar).display !== "none") {
        offset += mobileBar.offsetHeight;
    }

    // на десктопі панель фільтрів теж sticky — без цього запасу
    // вона накриє собою рядок "Знайдено N товарів"
    if (desktopBar && getComputedStyle(desktopBar).display !== "none") {
        offset += desktopBar.offsetHeight;
    }

    offset += 16;

    const top = target.getBoundingClientRect().top + window.scrollY - offset;

    window.scrollTo({ top: Math.max(top, 0), behavior: "smooth" });

}

// застосування будь-якого фільтра: перемальовуємо каталог і
// одразу підкручуємо сторінку до результатів
function applyFilterChange() {

    render();

    // у мобільній шторці "Всі фільтри" скрол не потрібен — там
    // результат застосовує кнопка "Показати N товарів", яка сама
    // викликає scrollToFirstProduct() після закриття шторки
    if (document.body.classList.contains("mobile-filters-open")) return;

    scrollToFirstProduct();

}

const sortToggle = document.getElementById("sortToggle");
const sortMenu = document.getElementById("sortMenu");
const sortLabel = document.getElementById("sortLabel");
const sortDropdown = document.getElementById("sortDropdown");

let currentSort = "";
let selectedBrands = new Set();
let selectedColors = new Set();
let selectedCategories = new Set();
// фільтр ціни — діапазон "від / до" (повзунок + два поля вводу).
// null означає "ще не ініціалізовано" — межі підставляються з
// реальних цін каталогу після його завантаження
let priceRange = { min: null, max: null };
let priceBounds = { min: 0, max: 0 };
let selectedSizes = new Set(); // елементи виду "group:size", напр. "bags:S"

// колір товару (для фільтра) — беремо прямо з variants,
// де hex вже заданий в адмінці; це й головне джерело правди
// для свотчів у фільтрі "Колір"
const SIZE_GROUPS = [
    {
        key: "bags",
        title: "Сумки",
        categories: ["Жіночі сумки", "Чоловічі сумки", "Унісекс сумки", "Дитячі сумки"],
        sizes: ["XS", "S", "M", "L"]
    },
    {
        key: "backpacks",
        title: "Рюкзаки",
        categories: ["Рюкзаки", "Дитячі рюкзаки"],
        sizes: ["S", "M", "L", "XL"]
    },
    {
        key: "clothes",
        title: "Одяг",
        // заповнюється в initCatalog() з даних data/categories.json
        categories: [],
        sizes: ["XS", "S", "M", "L", "XL", "XXL", "3XL", "4XL"]
    },
    {
        key: "shoes",
        title: "Взуття",
        // заповнюється в initCatalog() з даних data/categories.json
        categories: [],
        sizes: ["35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46"]
    }
];

// підтягує актуальний список категорій одягу/взуття з адмінки
// (data/categories.json) у відповідні групи розмірів
function applyCategoryDataToSizeGroups(categoryDepartments) {

    const clothesGroup = SIZE_GROUPS.find(g => g.key === "clothes");
    const shoesGroup = SIZE_GROUPS.find(g => g.key === "shoes");

    const clothesDept = categoryDepartments.find(d => d.title === "Одяг");
    const shoesDept = categoryDepartments.find(d => d.title === "Взуття");

    if (clothesGroup) clothesGroup.categories = clothesDept ? clothesDept.categories : [];
    if (shoesGroup) shoesGroup.categories = shoesDept ? shoesDept.categories : [];

}

// завантажує дерево категорій з адмінки (data/categories.json,
// зібраного зі списку окремих файлів data/categories/*.json)
// і групує його за розділами — у форматі, який очікують
// fillCategories() та applyCategoryDataToSizeGroups()
async function loadCategoryDepartments() {

    try {

        const response = await fetch("data/categories.json");

        if (!response.ok) return [];

        const categories = await response.json();

        const byDepartment = new Map();

        categories.forEach(category => {

            if (!byDepartment.has(category.department)) {
                byDepartment.set(category.department, { title: category.department, categories: [] });
            }

            byDepartment.get(category.department).categories.push(category.name);

        });

        return [...byDepartment.values()];

    } catch (error) {

        console.warn("Не вдалося завантажити категорії:", error);

        return [];

    }

}

function matchesSizeKey(product, key) {

    const [groupKey, size] = key.split(":");

    const group = SIZE_GROUPS.find(g => g.key === groupKey);

    if (!group) return false;

    return group.categories.includes(product.category) && (product.sizes || []).includes(size);

}

const categoryDropdown = document.getElementById("categoryDropdown");
const categoryToggle = document.getElementById("categoryToggle");
const categoryMenu = document.getElementById("categoryMenu");
const categoryLabel = document.getElementById("categoryLabel");
const categorySearchInput = document.getElementById("categorySearchInput");
const categoryOptionsList = document.getElementById("categoryOptionsList");
const categoryNoResults = document.getElementById("categoryNoResults");

// -------------------------
// Дропдаун «Бренд» (з пошуком)
// -------------------------

const brandDropdown = document.getElementById("brandDropdown");
const brandToggle = document.getElementById("brandToggle");
const brandMenu = document.getElementById("brandMenu");
const brandLabel = document.getElementById("brandLabel");
const brandSearchInput = document.getElementById("brandSearchInput");
const brandOptionsList = document.getElementById("brandOptionsList");
const brandNoResults = document.getElementById("brandNoResults");

// -------------------------
// Дропдаун «Колір»
// -------------------------

const colorDropdown = document.getElementById("colorDropdown");
const colorToggle = document.getElementById("colorToggle");
const colorMenu = document.getElementById("colorMenu");
const colorLabel = document.getElementById("colorLabel");
const colorOptionsList = document.getElementById("colorOptionsList");

// -------------------------
// Дропдаун «Ціна»
// -------------------------

const priceDropdown = document.getElementById("priceDropdown");
const priceToggle = document.getElementById("priceToggle");
const priceMenu = document.getElementById("priceMenu");
const priceLabel = document.getElementById("priceLabel");

// -------------------------
// Дропдаун «Розмір»
// -------------------------

const sizeDropdown = document.getElementById("sizeDropdown");
const sizeToggle = document.getElementById("sizeToggle");
const sizeMenu = document.getElementById("sizeMenu");
const sizeLabel = document.getElementById("sizeLabel");

const loader = document.getElementById("catalogLoader");
const emptyState = document.getElementById("emptyCatalog");

const productsCount = document.getElementById("productsCount");
const productsCounter = document.getElementById("productsCounter");

const resetBtn = document.getElementById("resetFilters");
const clearBtn = document.getElementById("clearSearch");

const gridViewBtn = document.getElementById("gridViewBtn");
const listViewBtn = document.getElementById("listViewBtn");

const genderFilterEl = document.getElementById("genderFilter");
const breadcrumbsList = document.getElementById("breadcrumbsList");
const catalogTitle = document.getElementById("catalogTitle");
const catalogSubtitle = document.getElementById("catalogSubtitle");

const activeFiltersBar = document.getElementById("activeFiltersBar");
const activeFiltersList = document.getElementById("activeFiltersList");
const activeFiltersChips = document.getElementById("activeFiltersChips");

let activeFiltersExpanded = false;

const GENDERS = ["Чоловікам", "Жінкам", "Унісекс", "Дітям"];
const SALE_MIN_DISCOUNT = 30; // % — мінімальна знижка для розділу "Акції"
const DEFAULT_BRAND_LABEL = "Бренд";
const DEFAULT_COLOR_LABEL = "Колір";
const DEFAULT_CATEGORY_LABEL = "Категорія";
const DEFAULT_PRICE_LABEL = "Ціна";
const DEFAULT_SIZE_LABEL = "Розмір";

// ціна без копійок і з розділювачем тисяч — "31 990"
function formatPrice(value) {

    return Math.round(value).toLocaleString("uk-UA").replace(/\u00A0/g, " ");

}

// фільтр вважається активним, тільки якщо користувач реально
// звузив діапазон відносно меж каталогу
function priceFilterActive() {

    if (priceRange.min === null || priceRange.max === null) return false;

    return priceRange.min > priceBounds.min || priceRange.max < priceBounds.max;

}

function priceRangeLabel() {

    const from = priceRange.min !== null ? priceRange.min : priceBounds.min;
    const to = priceRange.max !== null ? priceRange.max : priceBounds.max;

    return `${formatPrice(from)} – ${formatPrice(to)} грн`;

}

// формує підпис кнопки-дропдауна залежно від кількості обраних значень
function getMultiSelectLabel(selectedSet, defaultLabel, noun, labelForValue) {

    if (selectedSet.size === 0) return defaultLabel;

    const toLabel = labelForValue || (value => value);

    if (selectedSet.size === 1) return toLabel([...selectedSet][0]);

    return `${noun} (${selectedSet.size})`;

}

// поточний стан розділу, приходить з URL; стать — лише початкове
// значення фільтра, після завантаження сторінки завжди вільно змінюється
let currentSection = ""; // "" | "new" | "sale"
let selectedGenders = new Set(); // підмножина GENDERS

function readUrlState() {

    const params = new URLSearchParams(location.search);

    const section = params.get("section");
    currentSection = (section === "new" || section === "sale") ? section : "";

    const genderParam = params.get("gender");

    selectedGenders = new Set(
        (genderParam || "")
            .split(",")
            .map(v => v.trim())
            .filter(v => GENDERS.includes(v))
    );

}

async function initCatalog() {

    readUrlState();

    try {

        loader.hidden = false;

        const response = await fetch("data/products.json");

        if (!response.ok) {
            throw new Error("Не вдалося завантажити товари");
        }

        products = await response.json();

        const categoryDepartments = await loadCategoryDepartments();

        applyCategoryDataToSizeGroups(categoryDepartments);

        fillBrands();

        applyBrandFromUrl();

        fillColors();

        fillCategories(categoryDepartments);

        applyCategoryFromUrl();

        fillSizeGroups();

        applySearchFromUrl();

        setupGenderFilter();

        renderBreadcrumbsAndTitle();

        highlightNavLink();

        render();

        renderRecentlyViewed();

    } catch (error) {

        grid.innerHTML = `
            <p class="error">
                Помилка завантаження каталогу.
            </p>
        `;

        console.error(error);

    } finally {

        loader.hidden = true;

    }

}

// -------------------------
// Дропдаун «Бренд» (мультиселект)
// -------------------------

function fillBrands() {

    const brands = [...new Set(products.map(product => product.brand))].sort();

    brands.forEach(item => {

        const option = document.createElement("button");

        option.type = "button";
        option.className = "filter-option";
        option.dataset.brand = item;
        option.innerHTML = `<span class="filter-checkbox"></span>${item}`;

        option.addEventListener("click", () => toggleBrand(item));

        brandOptionsList.appendChild(option);

    });

}

function toggleBrand(value) {

    if (selectedBrands.has(value)) {

        selectedBrands.delete(value);

    } else {

        selectedBrands.add(value);

    }

    updateBrandUI();

    applyFilterChange();

}

function clearBrands() {

    selectedBrands.clear();

    updateBrandUI();

    closeAllDropdowns();

    applyFilterChange();

}

function updateBrandUI() {

    brandLabel.textContent = getMultiSelectLabel(selectedBrands, DEFAULT_BRAND_LABEL, "Бренди");

    brandOptionsList.querySelectorAll(".filter-option").forEach(o => {
        o.classList.toggle("active", selectedBrands.has(o.dataset.brand));
    });

}

function applySearchFromUrl() {

    const params = new URLSearchParams(location.search);

    const urlSearch = params.get("search");

    if (urlSearch) {

        search.value = urlSearch;

    }

}

function applyBrandFromUrl() {

    const params = new URLSearchParams(location.search);

    const urlBrand = params.get("brand");

    if (urlBrand) {

        const match = [...brandOptionsList.querySelectorAll(".filter-option")]
            .find(o => o.dataset.brand === urlBrand);

        if (match) {

            selectedBrands.add(urlBrand);

            updateBrandUI();

        }

    }

}

brandToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = brandMenu.hidden;

    closeAllDropdowns();

    if (willOpen) {

        openDropdownMenu(brandDropdown, brandMenu);
        brandSearchInput.value = "";
        filterBrandOptions("");
        brandSearchInput.focus();

    }

});

document.querySelector("[data-clear-brand]")?.addEventListener("click", clearBrands);

function filterBrandOptions(query) {

    const q = query.trim().toLowerCase();
    let visibleCount = 0;

    brandOptionsList.querySelectorAll(".filter-option").forEach(option => {

        const matches = option.dataset.brand.toLowerCase().includes(q);

        option.hidden = !matches;

        if (matches) visibleCount++;

    });

    if (brandNoResults) brandNoResults.hidden = q === "" || visibleCount !== 0;

}

brandSearchInput?.addEventListener("input", () => {

    filterBrandOptions(brandSearchInput.value);

});

brandSearchInput?.addEventListener("click", event => event.stopPropagation());

// -------------------------
// Дропдаун «Колір» (мультиселект, свотчі з даних товару)
// -------------------------

function fillColors() {

    if (!colorOptionsList) return;

    const colorSwatches = new Map(); // назва -> hex

    products.forEach(product => {

        getProductColors(product).forEach((hex, name) => {

            if (!colorSwatches.has(name) || (!colorSwatches.get(name) && hex)) {
                colorSwatches.set(name, hex);
            }

        });

    });

    [...colorSwatches.keys()]
        .sort((a, b) => a.localeCompare(b, "uk"))
        .forEach(name => {

            const hex = colorSwatches.get(name) || "#e5e7eb";

            const option = document.createElement("button");

            option.type = "button";
            option.className = "filter-option filter-option-color";
            option.dataset.color = name;
            option.innerHTML = `
                <span class="filter-checkbox"></span>
                <span class="filter-color-swatch" style="background:${hex}"></span>
                ${name}
            `;

            option.addEventListener("click", () => toggleColor(name));

            colorOptionsList.appendChild(option);

        });

}

function toggleColor(value) {

    if (selectedColors.has(value)) {

        selectedColors.delete(value);

    } else {

        selectedColors.add(value);

    }

    updateColorUI();

    applyFilterChange();

}

function clearColors() {

    selectedColors.clear();

    updateColorUI();

    closeAllDropdowns();

    applyFilterChange();

}

function updateColorUI() {

    colorLabel.textContent = getMultiSelectLabel(selectedColors, DEFAULT_COLOR_LABEL, "Кольори");

    colorOptionsList.querySelectorAll(".filter-option").forEach(o => {
        o.classList.toggle("active", selectedColors.has(o.dataset.color));
    });

}

document.querySelector("[data-clear-color]")?.addEventListener("click", clearColors);

colorToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = colorMenu.hidden;

    closeAllDropdowns();

    if (willOpen) openDropdownMenu(colorDropdown, colorMenu);

});

// -------------------------
// Дропдаун «Категорія» (з пошуком, згруповано по розділах)
// -------------------------

function fillCategories(categoryDepartments) {

    if (!categoryOptionsList || !Array.isArray(categoryDepartments)) return;

    const presentCategories = new Set(products.map(product => product.category));

    categoryDepartments.forEach(department => {

        const categoriesHere = department.categories.filter(c => presentCategories.has(c));

        if (categoriesHere.length === 0) return;

        const groupTitle = document.createElement("div");
        groupTitle.className = "filter-option-group-title";
        groupTitle.textContent = department.title;

        categoryOptionsList.appendChild(groupTitle);

        categoriesHere.forEach(category => {

            const option = document.createElement("button");

            option.type = "button";
            option.className = "filter-option";
            option.dataset.category = category;
            option.innerHTML = `<span class="filter-checkbox"></span>${category}`;

            option.addEventListener("click", () => toggleCategory(category));

            categoryOptionsList.appendChild(option);

        });

    });

}

function toggleCategory(value) {

    if (selectedCategories.has(value)) {

        selectedCategories.delete(value);

    } else {

        selectedCategories.add(value);

    }

    updateCategoryUI();

    applyFilterChange();

}

function clearCategories() {

    selectedCategories.clear();

    updateCategoryUI();

    closeAllDropdowns();

    applyFilterChange();

}

function updateCategoryUI() {

    categoryLabel.textContent = getMultiSelectLabel(selectedCategories, DEFAULT_CATEGORY_LABEL, "Категорії");

    categoryOptionsList.querySelectorAll(".filter-option").forEach(o => {
        o.classList.toggle("active", selectedCategories.has(o.dataset.category));
    });

}

function applyCategoryFromUrl() {

    const params = new URLSearchParams(location.search);

    const urlCategory = params.get("category");

    if (urlCategory) {

        const match = [...categoryOptionsList.querySelectorAll(".filter-option")]
            .find(o => o.dataset.category === urlCategory);

        if (match) {

            selectedCategories.add(urlCategory);

            updateCategoryUI();

        }

    }

}

categoryToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = categoryMenu.hidden;

    closeAllDropdowns();

    if (willOpen) {

        openDropdownMenu(categoryDropdown, categoryMenu);
        categorySearchInput.value = "";
        filterCategoryOptions("");
        categorySearchInput.focus();

    }

});

document.querySelector("[data-clear-category]")?.addEventListener("click", clearCategories);

function filterCategoryOptions(query) {

    const q = query.trim().toLowerCase();
    let visibleCount = 0;

    categoryOptionsList.querySelectorAll(".filter-option-group-title").forEach(title => {
        title.hidden = false;
    });

    categoryOptionsList.querySelectorAll(".filter-option").forEach(option => {

        const matches = option.dataset.category.toLowerCase().includes(q);

        option.hidden = !matches;

        if (matches) visibleCount++;

    });

    // ховаємо заголовки розділів, у яких після пошуку не лишилось жодної категорії
    let currentGroup = null;

    categoryOptionsList.querySelectorAll(".filter-option-group-title, .filter-option").forEach(el => {

        if (el.classList.contains("filter-option-group-title")) {

            if (currentGroup) currentGroup.hidden = currentGroup.hasVisible ? false : true;

            currentGroup = el;
            currentGroup.hasVisible = false;

        } else if (currentGroup && !el.hidden) {

            currentGroup.hasVisible = true;

        }

    });

    if (currentGroup) currentGroup.hidden = currentGroup.hasVisible ? false : true;

    if (categoryNoResults) categoryNoResults.hidden = q === "" || visibleCount !== 0;

}

categorySearchInput?.addEventListener("input", () => {

    filterCategoryOptions(categorySearchInput.value);

});

categorySearchInput?.addEventListener("click", event => event.stopPropagation());

// -------------------------
// Дропдаун «Ціна» — повзунок діапазону "від / до"
//
// Розмітка повзунка будується тут, у JS, а не в catalog.html /
// promo.html — щоб обидві сторінки автоматично отримали однаковий
// фільтр, а межі діапазону підставились з реальних цін каталогу.
// -------------------------

let priceUI = null;

// крок повзунка підбираємо під розмах цін, щоб ручка рухалась
// плавно, але значення лишались "круглими"
function priceStep(span) {

    if (span > 20000) return 100;
    if (span > 5000) return 50;
    if (span > 1000) return 10;

    return 1;

}

function buildPriceUI() {

    if (!priceMenu) return;

    const clearBtn = priceMenu.querySelector("[data-clear-price]");

    priceMenu.innerHTML = "";

    if (clearBtn) priceMenu.appendChild(clearBtn);

    const box = document.createElement("div");

    box.className = "price-range";

    box.innerHTML = `
        <div class="price-range-slider">
            <div class="price-range-track"></div>
            <div class="price-range-fill"></div>
            <input type="range" class="price-range-input price-range-min" aria-label="Ціна від">
            <input type="range" class="price-range-input price-range-max" aria-label="Ціна до">
        </div>
        <div class="price-range-fields">
            <label class="price-range-field">
                <input type="text" inputmode="numeric" class="price-range-number price-range-number-min" aria-label="Ціна від">
                <span class="price-range-suffix">грн</span>
            </label>
            <span class="price-range-dash">—</span>
            <label class="price-range-field">
                <input type="text" inputmode="numeric" class="price-range-number price-range-number-max" aria-label="Ціна до">
                <span class="price-range-suffix">грн</span>
            </label>
        </div>
    `;

    priceMenu.appendChild(box);

    priceUI = {
        box,
        fill: box.querySelector(".price-range-fill"),
        rangeMin: box.querySelector(".price-range-min"),
        rangeMax: box.querySelector(".price-range-max"),
        numberMin: box.querySelector(".price-range-number-min"),
        numberMax: box.querySelector(".price-range-number-max")
    };

    // клік усередині повзунка не має закривати дропдаун
    box.addEventListener("click", event => event.stopPropagation());

    // тягнемо ручку — числа під повзунком оновлюються миттєво,
    // а сам каталог перемальовується вже на відпусканні, щоб не
    // рендерити сітку на кожен піксель руху
    [priceUI.rangeMin, priceUI.rangeMax].forEach(input => {

        input.addEventListener("input", () => {

            readPriceSliders();
            paintPriceUI();

        });

        input.addEventListener("change", () => {

            readPriceSliders();
            updatePriceUI();
            applyFilterChange();

        });

    });

    [priceUI.numberMin, priceUI.numberMax].forEach(input => {

        input.addEventListener("change", commitPriceNumbers);

        input.addEventListener("keydown", event => {

            if (event.key === "Enter") {

                event.preventDefault();

                input.blur();

            }

        });

    });

}

function readPriceSliders() {

    if (!priceUI) return;

    let min = Number(priceUI.rangeMin.value);
    let max = Number(priceUI.rangeMax.value);

    // ручки не мають "перестрибувати" одна одну — та, за яку
    // зараз тягнуть, штовхає другу перед собою
    if (min > max) {

        if (document.activeElement === priceUI.rangeMin) {
            max = min;
        } else {
            min = max;
        }

    }

    priceRange.min = min;
    priceRange.max = max;

}

function parsePriceInput(value, fallback) {

    const digits = String(value).replace(/[^\d]/g, "");

    if (!digits) return fallback;

    return Number(digits);

}

function commitPriceNumbers() {

    if (!priceUI) return;

    let min = parsePriceInput(priceUI.numberMin.value, priceBounds.min);
    let max = parsePriceInput(priceUI.numberMax.value, priceBounds.max);

    min = Math.min(Math.max(min, priceBounds.min), priceBounds.max);
    max = Math.min(Math.max(max, priceBounds.min), priceBounds.max);

    // ввели "від" більше за "до" — просто міняємо місцями,
    // це майже завжди саме те, що людина мала на увазі
    if (min > max) {

        const swap = min;

        min = max;
        max = swap;

    }

    priceRange.min = min;
    priceRange.max = max;

    updatePriceUI();

    applyFilterChange();

}

// перемальовує сам повзунок і поля під ним під поточний стан
function paintPriceUI() {

    if (!priceUI) return;

    const min = priceRange.min !== null ? priceRange.min : priceBounds.min;
    const max = priceRange.max !== null ? priceRange.max : priceBounds.max;

    priceUI.rangeMin.value = min;
    priceUI.rangeMax.value = max;

    // поле, яке зараз редагують, не чіпаємо — інакше форматування
    // з'їдало б цифри прямо під час набору
    if (document.activeElement !== priceUI.numberMin) {
        priceUI.numberMin.value = formatPrice(min);
    }

    if (document.activeElement !== priceUI.numberMax) {
        priceUI.numberMax.value = formatPrice(max);
    }

    const span = priceBounds.max - priceBounds.min || 1;

    const left = ((min - priceBounds.min) / span) * 100;
    const right = ((max - priceBounds.min) / span) * 100;

    priceUI.fill.style.left = left + "%";
    priceUI.fill.style.width = Math.max(right - left, 0) + "%";

    // коли обидві ручки зійшлись у правому краї, верхня перекриває
    // нижню — піднімаємо ту, за яку ще реально можна взятись
    priceUI.rangeMin.style.zIndex = min >= priceBounds.max ? 5 : 3;

}

// межі беремо з реальних цін каталогу один раз, після його
// завантаження — далі вони не залежать від інших фільтрів,
// інакше повзунок "стрибав" би після кожного вибору
function setupPriceRange() {

    if (!priceMenu || !products.length) return;

    const prices = products
        .map(product => Number(product.price))
        .filter(value => Number.isFinite(value));

    if (!prices.length) return;

    const rawMin = Math.min(...prices);
    const rawMax = Math.max(...prices);

    const step = priceStep(rawMax - rawMin);

    priceBounds.min = Math.floor(rawMin / step) * step;
    priceBounds.max = Math.ceil(rawMax / step) * step;

    if (priceBounds.max === priceBounds.min) priceBounds.max = priceBounds.min + step;

    if (!priceUI) buildPriceUI();

    [priceUI.rangeMin, priceUI.rangeMax].forEach(input => {

        input.min = priceBounds.min;
        input.max = priceBounds.max;
        input.step = step;

    });

    // якщо межі ще не чіпали — розтягуємо діапазон на весь каталог
    if (priceRange.min === null) priceRange.min = priceBounds.min;
    if (priceRange.max === null) priceRange.max = priceBounds.max;

    priceRange.min = Math.max(priceRange.min, priceBounds.min);
    priceRange.max = Math.min(priceRange.max, priceBounds.max);

    updatePriceUI();

}

function clearPrices() {

    priceRange.min = priceBounds.min;
    priceRange.max = priceBounds.max;

    updatePriceUI();

    closeAllDropdowns();

    applyFilterChange();

}

function updatePriceUI() {

    if (priceLabel) {

        priceLabel.textContent = priceFilterActive() ? priceRangeLabel() : DEFAULT_PRICE_LABEL;

    }

    paintPriceUI();

}

// кнопка "Скинути вибір ціни" живе всередині priceMenu, який
// перебудовується при ініціалізації повзунка — тому обробник
// делегований на саме меню, а не на кнопку
priceMenu?.addEventListener("click", event => {

    if (event.target.closest("[data-clear-price]")) clearPrices();

});

priceToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = priceMenu.hidden;

    closeAllDropdowns();

    if (willOpen) openDropdownMenu(priceDropdown, priceMenu);

});

// -------------------------
// Дропдаун «Розмір» (мультиселект, з групами)
// -------------------------

const sizeGroupsList = document.getElementById("sizeGroupsList");

function fillSizeGroups() {

    if (!sizeGroupsList) return;

    const presentCategories = new Set(products.map(product => product.category));

    sizeGroupsList.innerHTML = SIZE_GROUPS
        .filter(group => group.categories.some(c => presentCategories.has(c)))
        .map(group => `
            <div class="filter-size-group">
                <div class="filter-size-group-title">${group.title}</div>
                <div class="filter-size-chips">
                    ${group.sizes.map(size => `
                        <button type="button" class="filter-size-chip" data-group="${group.key}" data-size="${size}">${size}</button>
                    `).join("")}
                </div>
            </div>
        `)
        .join("");

}

sizeGroupsList?.addEventListener("click", event => {

    const chip = event.target.closest(".filter-size-chip");

    if (!chip) return;

    toggleSize(`${chip.dataset.group}:${chip.dataset.size}`);

});

function toggleSize(key) {

    if (selectedSizes.has(key)) {

        selectedSizes.delete(key);

    } else {

        selectedSizes.add(key);

    }

    updateSizeUI();

    applyFilterChange();

}

function clearSizes() {

    selectedSizes.clear();

    updateSizeUI();

    closeAllDropdowns();

    applyFilterChange();

}

function sizeKeyLabel(key) {

    const [groupKey, size] = key.split(":");

    const group = SIZE_GROUPS.find(g => g.key === groupKey);

    return group ? `${group.title} · ${size}` : size;

}

function updateSizeUI() {

    sizeLabel.textContent = getMultiSelectLabel(selectedSizes, DEFAULT_SIZE_LABEL, "Розмір", sizeKeyLabel);

    sizeMenu.querySelectorAll(".filter-size-chip").forEach(chip => {

        const key = `${chip.dataset.group}:${chip.dataset.size}`;

        chip.classList.toggle("active", selectedSizes.has(key));

    });

}

document.querySelector("[data-clear-size]")?.addEventListener("click", clearSizes);

sizeToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = sizeMenu.hidden;

    closeAllDropdowns();

    if (willOpen) openDropdownMenu(sizeDropdown, sizeMenu);

});

function closeAllDropdowns() {

    [sortDropdown, brandDropdown, colorDropdown, categoryDropdown, priceDropdown, sizeDropdown].forEach(dropdown => {

        if (!dropdown) return;

        const menu = dropdown.querySelector(".filter-menu, .sort-menu");

        if (menu) {

            menu.hidden = true;

            // ОБОВ'ЯЗКОВО знімаємо і суто візуальне приховування
            // від скролу. Саме залишок цього класу був причиною
            // бага "список не відкривається на середині каталогу":
            // menu.hidden ставав false і додавався .open, але меню
            // лишалось з opacity:0 та pointer-events:none — тобто
            // невидимим, і "оживало" лише після скролу вгору.
            menu.classList.remove("scroll-hidden");

        }

        dropdown.classList.remove("open");

    });

}

// єдина точка відкриття будь-якого дропдауна фільтрів: меню
// показується одразу, незалежно від того, в якому місці каталогу
// зараз користувач і що відбувалось зі скролом раніше. Панель
// фільтрів sticky, тож список з'являється рівно під шапкою.
function openDropdownMenu(dropdown, menu) {

    if (!dropdown || !menu) return;

    closeAllDropdowns();

    menu.hidden = false;
    menu.classList.remove("scroll-hidden");

    dropdown.classList.add("open");

    // якщо панель фільтрів у цей момент була відведена вгору після
    // скролу вниз — повертаємо її на місце, інакше меню відкрилось
    // би разом з нею за межами екрана
    const stickyBar = dropdown.closest(".catalog-filters-bar, .mobile-filter-bar");

    if (stickyBar) stickyBar.classList.remove("is-hidden");

}

document.addEventListener("click", event => {

    if (event.target.closest("#sortDropdown, #brandDropdown, #colorDropdown, #categoryDropdown, #priceDropdown, #sizeDropdown")) return;

    closeAllDropdowns();

});

// -------------------------
// Приховування відкритого дропдауна фільтрів при скролі
//
// Меню дропдауна (.filter-menu / .sort-menu) — position:absolute
// відносно кнопки-тригера. Через це, коли сторінку прокручують
// вниз, кнопка-тригер може виїхати за межі екрана раніше, ніж
// саме меню (воно значно вище за кнопку) — і меню лишається
// висіти "у повітрі" поверх товарів нижче, вже не прив'язане до
// жодної видимої кнопки.
//
// Тут — суто візуальне приховування на час скролу вниз (клас
// scroll-hidden), окремо від "по-справжньому закрито" (menu.hidden
// + відсутність класу .open, як і раніше керує closeAllDropdowns).
// При скролі вгору знову показуємо дропдаун, якщо користувач сам
// його не закрив (тобто якщо menu.hidden усе ще false).
(function setupDropdownScrollVisibility() {

    let lastScrollY = window.scrollY;
    let ticking = false;

    const SCROLL_THRESHOLD = 4;

    function update() {

        const currentScrollY = window.scrollY;
        const delta = currentScrollY - lastScrollY;

        if (Math.abs(delta) > SCROLL_THRESHOLD) {

            const openDropdown = [sortDropdown, brandDropdown, colorDropdown, categoryDropdown, priceDropdown, sizeDropdown]
                .find(dropdown => dropdown?.classList.contains("open"));

            const menu = openDropdown?.querySelector(".filter-menu, .sort-menu");

            if (menu && !menu.hidden) {

                menu.classList.toggle("scroll-hidden", delta > 0);

            }

        }

        lastScrollY = currentScrollY;
        ticking = false;

    }

    window.addEventListener("scroll", () => {

        if (ticking) return;

        ticking = true;
        requestAnimationFrame(update);

    }, { passive: true });

})();

// -------------------------
// Фільтр «Стать»
// -------------------------

function updateGenderUI() {

    if (!genderFilterEl) return;

    genderFilterEl.querySelectorAll(".gender-pill").forEach(btn => {

        const value = btn.dataset.gender;

        btn.classList.toggle(
            "active",
            value === "" ? selectedGenders.size === 0 : selectedGenders.has(value)
        );

    });

}

function setupGenderFilter() {

    if (!genderFilterEl) return;

    updateGenderUI();

    genderFilterEl.querySelectorAll(".gender-pill").forEach(btn => {

        btn.addEventListener("click", () => {

            const value = btn.dataset.gender;

            if (value === "") {

                selectedGenders.clear();

            } else if (selectedGenders.has(value)) {

                selectedGenders.delete(value);

            } else {

                selectedGenders.add(value);

            }

            updateGenderUI();

            applyFilterChange();

        });

    });

}

// -------------------------
// Хлібні крихти + заголовок
// -------------------------

function renderBreadcrumbsAndTitle() {

    const crumbs = [`<a href="/">Головна</a>`];

    let title = "Каталог сумок";
    let subtitle = "Понад 500 моделей від світових брендів";

    if (currentSection === "new") {

        crumbs.push(`<span class="crumb-sep">→</span>`, `<a href="catalog?section=new">Новинки</a>`);
        title = "Новинки";
        subtitle = "Останні надходження до каталогу Bagvero";

    } else if (currentSection === "sale") {

        crumbs.push(`<span class="crumb-sep">→</span>`, `<span class="sale-text">Акції</span>`);
        title = `<span class="sale-text">Акції</span>`;
        subtitle = `Знижки від ${SALE_MIN_DISCOUNT}% на сумки, рюкзаки та аксесуари`;

    } else {

        crumbs.push(`<span class="crumb-sep">→</span>`, `<a href="catalog">Каталог</a>`);

    }

    if (selectedGenders.size) {

        const label = [...selectedGenders].join(", ");

        crumbs.push(`<span class="crumb-sep">→</span>`, `<span>${label}</span>`);
        subtitle = `${subtitle} · ${label}`;

    }

    if (breadcrumbsList) breadcrumbsList.innerHTML = crumbs.join("\n");

    if (catalogTitle) catalogTitle.innerHTML = title;
    if (catalogSubtitle) catalogSubtitle.textContent = subtitle;

    document.title = currentSection === "sale"
        ? "Акції | Bagvero"
        : currentSection === "new"
            ? "Новинки | Bagvero"
            : "Каталог | Bagvero";

}

function highlightNavLink() {

    const catalogLink = document.getElementById("navCatalogLink");
    const newLink = document.getElementById("navNewLink");
    const saleLink = document.getElementById("navSaleLink");

    [catalogLink, newLink, saleLink].forEach(el => el?.classList.remove("active"));

    if (currentSection === "new") {
        newLink?.classList.add("active");
    } else if (currentSection === "sale") {
        saleLink?.classList.add("active");
    } else {
        catalogLink?.classList.add("active");
    }

}

// -------------------------
// Фільтрація товарів
// -------------------------

function filterProducts() {

    let list = [...products];

    if (currentSection === "new") {

        list = list.filter(product => product.isNew);

    } else if (currentSection === "sale") {

        list = list.filter(product => {

            if (!product.oldPrice) return false;

            const discount = (1 - product.price / product.oldPrice) * 100;

            return discount >= SALE_MIN_DISCOUNT;

        });

    }

    if (selectedGenders.size) {

        list = list.filter(product => selectedGenders.has(product.gender));

    }

    const text = search.value.trim().toLowerCase();

    if (text) {

        list = list.filter(product => {

            const haystack = [
                product.title,
                product.brand,
                product.category,
                product.description,
                ...(product.searchKeywords || [])
            ].filter(Boolean).join(" ").toLowerCase();

            return haystack.includes(text);

        });

    }

    if (selectedBrands.size) {

        list = list.filter(product =>
            selectedBrands.has(product.brand)
        );

    }

    if (selectedColors.size) {

        list = list.filter(product => {

            const productColorNames = new Set(getProductColors(product).keys());

            return [...selectedColors].some(color => productColorNames.has(color));

        });

    }

    if (selectedCategories.size) {

        list = list.filter(product =>
            selectedCategories.has(product.category)
        );

    }

    if (priceFilterActive()) {

        list = list.filter(product =>
            product.price >= priceRange.min && product.price <= priceRange.max
        );

    }

    if (selectedSizes.size) {

        list = list.filter(product =>
            [...selectedSizes].some(key => matchesSizeKey(product, key))
        );

    }

    switch (currentSort) {

        case "new":
            list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
            break;

        case "top":
            list.sort((a, b) => (b.badge === "TOP" ? 1 : 0) - (a.badge === "TOP" ? 1 : 0));
            break;

        case "priceAsc":
            list.sort((a, b) => a.price - b.price);
            break;

        case "priceDesc":
            list.sort((a, b) => b.price - a.price);
            break;

        case "discount":
            list.sort((a, b) => getDiscountPercent(b) - getDiscountPercent(a));
            break;

    }

    return list;

}

function render() {

    // межі повзунка ціни залежать від завантажених товарів —
    // виставляємо їх один раз, при першому рендері з даними
    // (працює і для catalog.html, і для promo.html)
    if (!priceUI && products.length) setupPriceRange();

    const list = filterProducts();

    grid.innerHTML = list
        .map(product => createProductCard(product))
        .join("");

    initProductCarousels(grid);

    updateFavoriteButtons();

    productsCount.textContent = list.length;

    if (productsCounter) {

        productsCounter.textContent = `(${list.length})`;

    }

    emptyState.hidden = list.length !== 0;

    renderActiveFilters();

}

// -------------------------
// Рядок активних фільтрів (чіпи з хрестиком)
// -------------------------

function renderActiveFilters() {

    if (!activeFiltersBar || !activeFiltersChips) return;

    const chips = [];

    const text = search.value.trim();

    if (text) {

        chips.push({ type: "search", label: `Пошук: «${text}»` });

    }

    selectedGenders.forEach(gender => {

        chips.push({ type: "gender", value: gender, label: gender });

    });

    selectedBrands.forEach(brand => {

        chips.push({ type: "brand", value: brand, label: brand });

    });

    selectedColors.forEach(color => {

        chips.push({ type: "color", value: color, label: color });

    });

    selectedCategories.forEach(category => {

        chips.push({ type: "category", value: category, label: category });

    });

    if (priceFilterActive()) {

        chips.push({ type: "price", value: "", label: priceRangeLabel() });

    }

    selectedSizes.forEach(key => {

        chips.push({ type: "size", value: key, label: sizeKeyLabel(key) });

    });

    if (chips.length === 0) {

        activeFiltersBar.hidden = true;
        activeFiltersChips.innerHTML = "";
        activeFiltersExpanded = false;

        return;

    }

    activeFiltersBar.hidden = false;

    activeFiltersChips.innerHTML = chips.map(chip => `
        <button type="button" class="filter-chip" data-clear="${chip.type}" data-value="${chip.value || ""}">
            ${chip.label}
            <span class="filter-chip-x">✕</span>
        </button>
    `).join("");

    layoutActiveFilters();

}

// -------------------------
// Обмежуємо активні фільтри двома рядками,
// решту ховаємо за кнопкою "+N фільтрів"
// -------------------------

function pluralizeFilters(n) {

    const mod10 = n % 10;
    const mod100 = n % 100;

    if (mod10 === 1 && mod100 !== 11) return "фільтр";
    if (mod10 >= 2 && mod10 <= 4 && !(mod100 >= 12 && mod100 <= 14)) return "фільтри";

    return "фільтрів";

}

function layoutActiveFilters() {

    if (!activeFiltersChips) return;

    const label = document.querySelector(".active-filters-label");
    const chipButtons = Array.from(activeFiltersChips.querySelectorAll(".filter-chip"));

    const existingMore = activeFiltersChips.querySelector(".filter-more-chip");
    if (existingMore) existingMore.remove();

    chipButtons.forEach(el => el.classList.remove("filter-chip-hidden"));

    if (chipButtons.length === 0) return;

    const measureItems = [label, ...chipButtons].filter(Boolean);
    const rowTops = [...new Set(measureItems.map(el => el.offsetTop))];

    const overflowChips = rowTops.length > 2
        ? chipButtons.filter(el => el.offsetTop > rowTops[1])
        : [];

    if (overflowChips.length === 0) return;

    const moreBtn = document.createElement("button");
    moreBtn.type = "button";
    moreBtn.className = "filter-chip filter-more-chip";

    if (activeFiltersExpanded) {

        moreBtn.textContent = "Згорнути ▴";

    } else {

        overflowChips.forEach(el => el.classList.add("filter-chip-hidden"));

        moreBtn.textContent = `+${overflowChips.length} ${pluralizeFilters(overflowChips.length)}`;

    }

    activeFiltersChips.appendChild(moreBtn);

}

window.addEventListener("resize", debounce(() => {

    if (activeFiltersBar && !activeFiltersBar.hidden) layoutActiveFilters();

}, 200));

function debounce(fn, delay) {

    let timer = null;

    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };

}

activeFiltersList?.addEventListener("click", event => {

    const moreBtn = event.target.closest(".filter-more-chip");

    if (moreBtn) {

        activeFiltersExpanded = !activeFiltersExpanded;
        layoutActiveFilters();

        return;

    }

    const chip = event.target.closest(".filter-chip");

    if (!chip || chip.classList.contains("filter-more-chip")) return;

    clearOneFilter(chip.dataset.clear, chip.dataset.value);

});

function clearOneFilter(type, value) {

    if (type === "search") {

        search.value = "";

    } else if (type === "gender") {

        selectedGenders.delete(value);
        updateGenderUI();

    } else if (type === "brand") {

        selectedBrands.delete(value);

        updateBrandUI();

    } else if (type === "color") {

        selectedColors.delete(value);

        updateColorUI();

    } else if (type === "category") {

        selectedCategories.delete(value);

        updateCategoryUI();

    } else if (type === "price") {

        priceRange.min = priceBounds.min;
        priceRange.max = priceBounds.max;

        updatePriceUI();

    } else if (type === "size") {

        selectedSizes.delete(value);

        updateSizeUI();

    }

    applyFilterChange();

}

function resetAllFilters() {

    search.value = "";

    selectedBrands.clear();
    updateBrandUI();

    selectedColors.clear();
    updateColorUI();

    selectedCategories.clear();
    updateCategoryUI();

    priceRange.min = priceBounds.min;
    priceRange.max = priceBounds.max;
    updatePriceUI();

    selectedSizes.clear();
    updateSizeUI();

    currentSort = "";

    if (sortLabel) sortLabel.textContent = "за замовчуванням";

    sortMenu?.querySelectorAll(".sort-option").forEach(o => {
        o.classList.toggle("active", o.dataset.sort === "");
    });

    selectedGenders.clear();
    updateGenderUI();

    applyFilterChange();

}

resetBtn?.addEventListener("click", resetAllFilters);

clearBtn?.addEventListener("click", resetAllFilters);

search.addEventListener("input", render);

// -------------------------
// Кастомний дропдаун сортування
// -------------------------

sortToggle?.addEventListener("click", event => {

    event.stopPropagation();

    const willOpen = sortMenu.hidden;

    closeAllDropdowns();

    if (willOpen) openDropdownMenu(sortDropdown, sortMenu);

});

sortMenu?.querySelectorAll(".sort-option").forEach(option => {

    option.addEventListener("click", () => {

        currentSort = option.dataset.sort;

        sortLabel.textContent = option.dataset.label;

        sortMenu.querySelectorAll(".sort-option").forEach(o => o.classList.toggle("active", o === option));

        closeAllDropdowns();

        applyFilterChange();

    });

});

// -------------------------
// Перемикач "плитка / список"
// -------------------------

function setView(mode) {

    grid.classList.toggle("list-view", mode === "list");

    gridViewBtn?.classList.toggle("active", mode === "grid");
    listViewBtn?.classList.toggle("active", mode === "list");

    localStorage.setItem("catalogView", mode);

}

gridViewBtn?.addEventListener("click", () => setView("grid"));
listViewBtn?.addEventListener("click", () => setView("list"));

setView(localStorage.getItem("catalogView") || "grid");

// сторінки на кшталт promo.html підключають цей самий файл,
// щоб повністю перевикористати "двигун" фільтрів/сортування,
// але самі вирішують, які товари в нього підставити (замість
// повного каталогу) — тому виставляють цей прапорець ДО
// підключення catalog.js і викликають потрібні функції вручну
if (!window.CATALOG_SKIP_AUTO_INIT) {

    initCatalog();

}

// =====================================
// МОБІЛЬНІ ФІЛЬТРИ КАТАЛОГУ
// (закріплена панель "Фільтри/Сортування" під хедером
// + повноекранна шторка зі списком фільтрів; на відміну
// від старого мобільного вигляду (стек інпутів на всю
// ширину) реальні DOM-вузли дропдаунів просто переносяться
// в шторку і назад — без дублювання логіки фільтрації)
// =====================================

(function setupMobileFilters() {

    const mobileFilterBar = document.getElementById("mobileFilterBar");
    const mobileFiltersBtn = document.getElementById("mobileFiltersBtn");
    const mobileFiltersCount = document.getElementById("mobileFiltersCount");
    const mobileFiltersModal = document.getElementById("mobileFiltersModal");
    const mobileFiltersMain = document.getElementById("mobileFiltersMain");
    const mobileFiltersSub = document.getElementById("mobileFiltersSub");
    const mobileFiltersSubTitle = document.getElementById("mobileFiltersSubTitle");
    const mobileFiltersSubContent = document.getElementById("mobileFiltersSubContent");
    const mobileFiltersCloseBtn = document.getElementById("mobileFiltersCloseBtn");
    const mobileFiltersCloseBtn2 = document.getElementById("mobileFiltersCloseBtn2");
    const mobileFiltersBackBtn = document.getElementById("mobileFiltersBackBtn");
    const mobileFiltersResetBtn = document.getElementById("mobileFiltersResetBtn");
    const mobileFiltersApplyBtn = document.getElementById("mobileFiltersApplyBtn");
    const mobileFiltersSubApplyBtn = document.getElementById("mobileFiltersSubApplyBtn");
    const mobileFiltersRows = document.getElementById("mobileFiltersRows");
    const sortDropdownAnchor = document.getElementById("sortDropdownAnchor");
    const mfCount = document.getElementById("mfCount");
    const mfSubCount = document.getElementById("mfSubCount");

    if (!mobileFilterBar || !mobileFiltersModal) return;

    const mfRows = {
        category: document.getElementById("mfRowCategory"),
        brand: document.getElementById("mfRowBrand"),
        color: document.getElementById("mfRowColor"),
        size: document.getElementById("mfRowSize"),
        gender: document.getElementById("mfRowGender"),
        price: document.getElementById("mfRowPrice")
    };

    // реальні вузли десктопних дропдаунів, які на мобільному
    // переносяться в шторку (без клонування — з усіма їх
    // обробниками подій)
    const targets = {
        category: { el: categoryMenu, parent: categoryDropdown, title: "Категорія" },
        brand: { el: brandMenu, parent: brandDropdown, title: "Бренд" },
        color: { el: colorMenu, parent: colorDropdown, title: "Колір" },
        size: { el: sizeMenu, parent: sizeDropdown, title: "Розмір" },
        gender: { el: genderFilterEl, parent: genderFilterEl ? genderFilterEl.parentElement : null, title: "Стать" },
        price: { el: priceMenu, parent: priceDropdown, title: "Ціна" }
    };

    const mq = window.matchMedia("(max-width:768px)");

    function relocateSortDropdown() {

        if (!sortDropdown) return;

        if (mq.matches) {
            mobileFilterBar.appendChild(sortDropdown);
        } else if (sortDropdownAnchor) {
            sortDropdownAnchor.after(sortDropdown);
        }

    }

    function activeFilterCount() {

        return selectedGenders.size
            + selectedBrands.size
            + selectedColors.size
            + selectedCategories.size
            + (priceFilterActive() ? 1 : 0)
            + selectedSizes.size;

    }

    function refreshRowLabels() {

        if (mfRows.category) mfRows.category.textContent = categoryLabel ? categoryLabel.textContent : "";
        if (mfRows.brand) mfRows.brand.textContent = brandLabel ? brandLabel.textContent : "";
        if (mfRows.color) mfRows.color.textContent = colorLabel ? colorLabel.textContent : "";
        if (mfRows.size) mfRows.size.textContent = sizeLabel ? sizeLabel.textContent : "";
        if (mfRows.price) mfRows.price.textContent = priceLabel ? priceLabel.textContent : "";
        if (mfRows.gender) mfRows.gender.textContent = getMultiSelectLabel(selectedGenders, "Всі", "Стать");

        const count = activeFilterCount();

        if (mobileFiltersCount) {
            mobileFiltersCount.hidden = count === 0;
            mobileFiltersCount.textContent = count;
        }

    }

    function refreshCounts() {

        const n = productsCount ? productsCount.textContent : "0";

        if (mfCount) mfCount.textContent = n;
        if (mfSubCount) mfSubCount.textContent = n;

    }

    function returnRelocatedTargets() {

        Object.values(targets).forEach(target => {

            if (!target.el || !target.parent) return;

            if (target.el.parentElement !== target.parent) {

                target.parent.appendChild(target.el);

                if (target.el.classList.contains("filter-menu")) {
                    target.el.hidden = true;
                }

            }

        });

    }

    function openMobileFilters() {

        refreshRowLabels();
        refreshCounts();

        mobileFiltersSub.hidden = true;
        mobileFiltersMain.hidden = false;
        mobileFiltersModal.hidden = false;

        document.body.style.overflow = "hidden";
        document.body.classList.add("mobile-filters-open");

    }

    function closeMobileFilters() {

        returnRelocatedTargets();

        mobileFiltersModal.hidden = true;

        document.body.style.overflow = "";
        document.body.classList.remove("mobile-filters-open");

    }

    function openMobileFilterSection(key) {

        const target = targets[key];

        if (!target || !target.el) return;

        // скидаємо тільки текст пошуку (і показуємо знову всі
        // опції), вибрані категорія/бренд при цьому не чіпаємо —
        // інакше при поверненні в "Всі фільтри" і повторному вході
        // в розділ залишався старий текст пошуку
        if (key === "category" && categorySearchInput) {

            categorySearchInput.value = "";
            filterCategoryOptions("");

        } else if (key === "brand" && brandSearchInput) {

            brandSearchInput.value = "";
            filterBrandOptions("");

        }

        mobileFiltersSubTitle.textContent = target.title;
        mobileFiltersSubContent.innerHTML = "";
        mobileFiltersSubContent.appendChild(target.el);

        target.el.hidden = false;

        mobileFiltersMain.hidden = true;
        mobileFiltersSub.hidden = false;

        refreshCounts();

    }

    function backToMobileFiltersMain() {

        mobileFiltersSub.hidden = true;
        mobileFiltersMain.hidden = false;

        refreshRowLabels();
        refreshCounts();

    }

    mobileFiltersBtn?.addEventListener("click", openMobileFilters);
    mobileFiltersCloseBtn?.addEventListener("click", closeMobileFilters);
    mobileFiltersCloseBtn2?.addEventListener("click", closeMobileFilters);

    mobileFiltersApplyBtn?.addEventListener("click", () => {
        closeMobileFilters();
        scrollToFirstProduct();
    });

    mobileFiltersSubApplyBtn?.addEventListener("click", () => {
        closeMobileFilters();
        scrollToFirstProduct();
    });

    mobileFiltersBackBtn?.addEventListener("click", backToMobileFiltersMain);

    mobileFiltersResetBtn?.addEventListener("click", () => {

        resetAllFilters();

        refreshRowLabels();
        refreshCounts();

    });

    mobileFiltersRows?.addEventListener("click", event => {

        const row = event.target.closest(".mobile-filter-row");

        if (!row) return;

        openMobileFilterSection(row.dataset.target);

    });

    // тримаємо бейдж і лічильники товарів актуальними, поки
    // шторка відкрита і користувач одразу бачить результат тапу
    const baseRender = render;

    render = function() {

        baseRender();

        if (!mobileFiltersModal.hidden) {

            refreshCounts();

            if (!mobileFiltersMain.hidden) refreshRowLabels();

        }

    };

    function handleViewportChange() {

        relocateSortDropdown();

        if (!mq.matches && !mobileFiltersModal.hidden) {
            closeMobileFilters();
        }

    }

    relocateSortDropdown();

    if (mq.addEventListener) {
        mq.addEventListener("change", handleViewportChange);
    } else {
        mq.addListener(handleViewportChange);
    }

    // Ховаємо панель фільтрів при скролі вниз і показуємо назад
    // при скролі вгору (типова мобільна поведінка, застосовується
    // і на десктопі — та сама .catalog-filters-bar). Стежимо саме
    // за напрямком скролу, а не просто за позицією — і головне:
    // чіпаємо клас is-hidden лише коли панель вже реально "прилипла"
    // під шапкою (getBoundingClientRect().top === sticky top).
    // Це і є фікс старого бага: раніше клас перемикався завжди,
    // з самого початку — поки сторінка ще довантажувала banner
    // акції над каталогом, позиція панелі "гуляла" разом з layout
    // shift від картинки, і вона видимо "стрибала"/впиралась у
    // банер. Тепер поки панель не в прилиплому стані — ми її
    // взагалі не чіпаємо, вона просто рухається зі сторінкою як
    // завжди.
    function initStickyFilterAutoHide(el) {

        if (!el) return;

        let lastScrollY = window.scrollY;
        let ticking = false;

        const HIDE_THRESHOLD = 6; // щоб дрібний джиттер скролу не смикав панель туди-сюди
        const stickyTop = parseFloat(getComputedStyle(el).top) || 0;

        function updateVisibility() {

            const currentScrollY = window.scrollY;
            const delta = currentScrollY - lastScrollY;
            const isStuck = el.getBoundingClientRect().top <= stickyTop + 1;

            if (!isStuck) {

                el.classList.remove("is-hidden");

            } else if (Math.abs(delta) > HIDE_THRESHOLD) {

                const hiding = delta > 0;

                // При скролі вниз панель ховається трансформом
                // (translateY), а відкритий список вищий за неї, тож
                // сам зсув його повністю не прибирає. Раніше тут
                // викликався closeAllDropdowns() — список закривався
                // по-справжньому і після скролу вгору вже не
                // повертався (а через залишковий клас scroll-hidden
                // ще й не відкривався по кліку).
                //
                // Тепер список лише ховається візуально — клас
                // scroll-hidden ставить setupDropdownScrollVisibility,
                // і при скролі вгору він повертається сам, якщо
                // користувач його не закривав.
                el.classList.toggle("is-hidden", hiding);

            }

            lastScrollY = currentScrollY;
            ticking = false;

        }

        window.addEventListener("scroll", () => {
            if (ticking) return;
            ticking = true;
            requestAnimationFrame(updateVisibility);
        }, { passive: true });

    }

    initStickyFilterAutoHide(mobileFilterBar);

    // та сама поведінка на десктопі — для .catalog-filters-bar
    // (на вузьких екранах цей елемент display:none, тож там ця
    // ініціалізація просто нічого не робить)
    initStickyFilterAutoHide(document.querySelector(".catalog-filters-bar"));

})();
